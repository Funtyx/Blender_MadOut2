# =====================================================
# Area Lines — режет большие грани площадки (асфальт парковки,
# плитка, газон) прямыми линиями от точек края к противоположному
# краю: поперёк — продолжения разметки мест, вдоль — продолжения
# углов бордюров. Получаются ровные четырёхугольники, сваренные с
# тем, что уже стоит на краях. UV и высоты переносятся.
# =====================================================

import math

import bmesh
import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty
from mathutils import Vector

from .ui_help import draw_help

HELP = (
    "Что делает: большие грани площадки (асфальт,",
    "плитка, газон) режет прямыми линиями от точек",
    "края к противоположному краю — сетка из",
    "четырёхугольников, сваренная с краями.",
    "",
    "Что выделить: площадку целиком или только её",
    "большие грани. Бордюры, места разметки и мелкие",
    "грани не режутся (меньше «Мин. площадь»).",
    "",
    "Поперёк — продолжения разметки мест через проезд;",
    "вдоль — продолжения углов бордюров.",
    "Притяжка — если на другом краю рядом есть точка,",
    "линия идёт в неё, а не добавляет новую.",
    "Откат — Ctrl+Z.",
)


class _Fail(Exception):
    pass


def _cross(a, b):
    return a.x * b.y - a.y * b.x


def _inside(pt, poly):
    """Even-odd test of a plan point against a polygon of plan points."""
    hit = False
    n = len(poly)
    for i in range(n):
        a, b = poly[i], poly[(i + 1) % n]
        if (a.y > pt.y) != (b.y > pt.y):
            x = a.x + (pt.y - a.y) * (b.x - a.x) / (b.y - a.y)
            if x > pt.x:
                hit = not hit
    return hit


def _axes(poly):
    """The face's long direction: the boundary's edge directions folded to half a turn and weighted
    by length; the heaviest 2-degree bin, smoothed over its neighbours, wins."""
    bins = [0.0] * 90
    for a, b in zip(poly, poly[1:] + poly[:1]):
        d = b - a
        if d.length < 1e-6:
            continue
        ang = math.degrees(math.atan2(d.y, d.x)) % 180.0
        bins[int(ang / 2.0) % 90] += d.length
    best = max(range(90), key=lambda i: bins[i - 1] + 2.0 * bins[i] + bins[(i + 1) % 90])
    # length-weighted mean angle inside the winning bin and its neighbours
    acc = Vector((0.0, 0.0))
    for a, b in zip(poly, poly[1:] + poly[:1]):
        d = b - a
        if d.length < 1e-6:
            continue
        ang = math.degrees(math.atan2(d.y, d.x)) % 180.0
        diff = (ang - (best * 2.0 + 1.0) + 90.0) % 180.0 - 90.0
        if abs(diff) <= 3.0:
            dd = d.normalized() * d.length
            if dd.dot(Vector((math.cos(math.radians(best * 2.0)), math.sin(math.radians(best * 2.0))))) < 0:
                dd = -dd
            acc += dd
    u = acc.normalized() if acc.length > 1e-9 else Vector((math.cos(math.radians(best * 2 + 1)), math.sin(math.radians(best * 2 + 1))))
    return u, Vector((-u.y, u.x))


def _ray_exit(p, d, poly, skip):
    """The first point where a ray from boundary point p in direction d leaves the polygon:
    (distance, point, index of the boundary edge). skip is the index of p in the polygon."""
    n = len(poly)
    best = None
    for i in range(n):
        if i == skip or (i + 1) % n == skip:
            continue
        a, b = poly[i], poly[(i + 1) % n]
        e = b - a
        den = _cross(d, e)
        if abs(den) < 1e-12:
            continue
        w = a - p
        t = _cross(w, e) / den
        s = _cross(w, d) / den
        if t > 1e-4 and -1e-6 <= s <= 1.0 + 1e-6:
            if best is None or t < best[0]:
                best = (t, p + d * t, i)
    return best


def plan_lines(poly, settings):
    """The cut segments for one face: [(start index, end index or None, end point, family)]."""
    u, v = _axes(poly)
    n = len(poly)
    tol = math.radians(settings["angle"])
    out = []
    for i in range(n):
        p = poly[i]
        a = (p - poly[i - 1])
        b = (poly[(i + 1) % n] - p)
        if a.length < 1e-6 or b.length < 1e-6:
            continue
        a.normalize()
        b.normalize()
        if a.dot(b) < 0.5:
            continue  # a corner of the face: no clear side to continue
        side = (a + b).normalized()
        for fam, along_side, ray in (("cross", u, v), ("along", v, u)):
            if fam == "along" and not settings["along"]:
                continue
            off = side.angle(along_side)
            if min(off, math.pi - off) > tol:
                continue
            for d in (ray, -ray):
                if _inside(p + d * 0.05, poly):
                    hit = _ray_exit(p, d, poly, i)
                    if hit is None:
                        continue
                    t, h, edge = hit
                    if t < settings["min_len"]:
                        continue
                    # snap the far end to a point already on the boundary near it
                    near = min(range(n), key=lambda j: (poly[j] - h).length)
                    end_idx = near if (poly[near] - h).length <= settings["snap"] and near != i else None
                    end = poly[end_idx] if end_idx is not None else h
                    out.append((i, end_idx, end, fam, edge))
                    break
    # Drop duplicates (the same chord from both ends) and lines crowding one another
    kept = []
    for seg in sorted(out, key=lambda s: (s[3], -(s[2] - poly[s[0]]).length)):
        i, j, end, fam, _ = seg
        start = poly[i]
        dup = False
        for k in kept:
            if k[3] != fam:
                continue
            ks, ke = poly[k[0]], k[2]
            if ((ks - start).length < 1e-4 and (ke - end).length < 0.05) or \
               ((ks - end).length < 0.05 and (ke - start).length < 1e-4):
                dup = True
                break
            if ((ks - start).length < settings["gap"] and (ke - end).length < settings["gap"]) or \
               ((ks - end).length < settings["gap"] and (ke - start).length < settings["gap"]):
                dup = True
                break
        if not dup:
            kept.append(seg)
    return kept, u


def _face_poly(f, mw):
    return [(mw @ v.co).xy for v in f.verts]


def plan_grid(faces, u, mw, settings):
    """The lines of the grid: [(family, first end, last end, direction)].

    Every edge of the selection lying along one of the two directions (a kerb's edge, a stall line, an
    aisle's side) is a candidate. Candidates of one family nearer each other than settings['gap'] are
    one line - the longest edge of the group, run on from each of its two ends in the family's exact
    direction. Not one straight line through the edge: a stall line leaning 6 degrees off the frame
    is then crossed at 6 degrees by its own continuation, a sliver the length of the stall. And not
    the edge's own direction all the way: lines of one family leaning by different amounts cross
    each other inside the lot (tried - a web of triangles)."""
    v = Vector((-u.y, u.x))
    tol = math.radians(settings["angle_edges"])
    edges = {e for f in faces for e in f.edges}
    out = []
    for fam, d, across in (("along", u, v), ("cross", v, u)):
        if fam == "along" and not settings["along"]:
            continue
        cands = []
        for e in edges:
            a, b = (mw @ e.verts[0].co).xy, (mw @ e.verts[1].co).xy
            ed = b - a
            if ed.length < settings["min_edge"]:
                continue
            off = ed.angle(d)
            if min(off, math.pi - off) > tol:
                continue
            if a.dot(d) > b.dot(d):
                a, b = b, a
            cands.append((((a + b) * 0.5).dot(across), ed.length, a, b))
        # Longest first, each kept only if it is clear of every line kept before it. Grouping by
        # neighbours along the across axis instead chained: a group anchored on its first member let
        # the next group start just past it, and two lines 8 cm apart came out of that.
        kept = []
        for c in sorted(cands, key=lambda c: -c[1]):
            if all(abs(c[0] - k[0]) > settings["gap"] for k in kept):
                kept.append(c)
        for c in sorted(kept, key=lambda c: c[0]):
            out.append((fam, c[2], c[3], d))
    return out


def _cut_ray(bm, pieces, origin, d, mw, snap):
    """Cut every piece the plan ray from origin along d passes through. Where it crosses an edge
    within `snap` of one of its ends, it goes through that end instead of making a new point beside
    it - the alternative is a strip a few centimetres wide. Returns how many cuts were made.

    Each face is cut by the points of ITS OWN boundary on the line. Sorting every point on the line
    together and joining neighbours fails wherever two pieces lie side by side unwelded (a kerb on
    the asphalt): neighbours along the line then belong to different faces and nothing is cut - the
    whole aisle was left whole that way."""
    nrm = Vector((-d.y, d.x))
    on_line = set()
    done = set()
    for f in list(pieces):
        if not f.is_valid:
            continue
        for e in list(f.edges):
            if not e.is_valid or e in done:
                continue
            done.add(e)
            v0, v1 = e.verts
            p0, p1 = (mw @ v0.co).xy, (mw @ v1.co).xy
            s0, s1 = (p0 - origin).dot(nrm), (p1 - origin).dot(nrm)
            ahead0, ahead1 = (p0 - origin).dot(d) >= -1e-4, (p1 - origin).dot(d) >= -1e-4
            if abs(s0) <= 1e-4 and ahead0:
                on_line.add(v0)
            if abs(s1) <= 1e-4 and ahead1:
                on_line.add(v1)
            if abs(s0) <= 1e-4 or abs(s1) <= 1e-4 or s0 * s1 > 0.0:
                continue
            t = s0 / (s0 - s1)
            if (p0.lerp(p1, t) - origin).dot(d) < 1e-4:
                continue  # behind the ray's start
            length = (p1 - p0).length
            if t * length <= snap:
                on_line.add(v0)
            elif (1.0 - t) * length <= snap:
                on_line.add(v1)
            else:
                _, nv = bmesh.utils.edge_split(e, v0, t)
                on_line.add(nv)
    if not on_line:
        return 0
    cuts = 0
    queue = [f for f in pieces if f.is_valid and any(v in on_line for v in f.verts)]
    while queue:
        f = queue.pop()
        if not f.is_valid:
            continue
        ring = list(f.verts)
        mine = [v for v in ring if v in on_line]
        if len(mine) < 2:
            continue
        mine.sort(key=lambda vv: ((mw @ vv.co).xy - origin).dot(d))
        poly = _face_poly(f, mw)
        n = len(ring)
        idx = {v: i for i, v in enumerate(ring)}
        for p, q in zip(mine, mine[1:]):
            i, j = idx[p], idx[q]
            if (i - j) % n in (1, n - 1):
                continue  # already an edge of this face
            mid = ((mw @ p.co).xy + (mw @ q.co).xy) * 0.5
            if not _inside(mid, poly):
                continue
            try:
                nf, _ = bmesh.utils.face_split(f, p, q)
            except ValueError:
                continue
            if nf is None:
                continue
            pieces.add(nf)
            queue.append(f)
            queue.append(nf)
            cuts += 1
            break
    return cuts


class AreaLinesCore:
    """Cut the selection with the grid; parameters are read from self."""

    summary = (0, 0, 0, 0)
    thin = 1.5

    def _run(self, bm, obj):
        mw = obj.matrix_world
        settings = {"gap": self.gap, "along": self.lines == 'BOTH', "angle_edges": math.degrees(self.angle),
                    "min_edge": 0.25}
        faces = {f for f in bm.faces if f.select}
        big = [f for f in faces if len(f.verts) > 4 and _area(f, mw) >= self.min_area]
        if not faces:
            raise _Fail("Выделите площадку")
        ref = max(big, key=lambda f: _area(f, mw)) if big else max(faces, key=lambda f: _area(f, mw))
        u, _ = _axes(_face_poly(ref, mw))
        before = len(faces)
        lines = plan_grid(faces, u, mw, settings)
        pieces = set(faces)
        n_cross = n_along = 0
        for fam, a, b, d in lines:
            back = _cut_ray(bm, pieces, a, -d, mw, self.snap)
            ahead = _cut_ray(bm, pieces, b, d, mw, self.snap)
            if back or ahead:
                if fam == "cross":
                    n_cross += 1
                else:
                    n_along += 1
        made = {f for f in pieces if f.is_valid}
        for f in bm.faces:
            f.select = False
        for e in bm.edges:
            e.select = False
        for v in bm.verts:
            v.select = False
        for f in made:
            f.select = True
        bm.select_flush(True)
        bm.normal_update()
        self.summary = (before, len(made), n_cross, n_along)
        return list(made)


def _area(face, mw):
    pts = [(mw @ v.co) for v in face.verts]
    s = Vector()
    for i in range(1, len(pts) - 1):
        s += (pts[i] - pts[0]).cross(pts[i + 1] - pts[0])
    return s.length / 2.0


def describe(summary):
    before, made, cross, along = summary
    return f"Граней {before} → {made}; линий поперёк: {cross}, вдоль: {along}"


class MESH_OT_area_lines(AreaLinesCore, bpy.types.Operator):
    """Разрезать большие грани площадки прямыми линиями от точек края: ровная сетка, сваренная с краями"""
    bl_idname = "mesh.area_lines"
    bl_label = "Area Lines"
    bl_options = {'REGISTER', 'UNDO'}

    lines: EnumProperty(
        name="Линии", default='BOTH',
        items=[
            ('BOTH', "Поперёк и вдоль", "Продолжения разметки мест через проезд и продолжения углов бордюров"),
            ('CROSS', "Только поперёк", "Только продолжения разметки мест через проезд"),
        ])
    snap: FloatProperty(
        name="Притяжка", default=0.5, min=0.0, soft_max=3.0, unit='LENGTH',
        description="Если на другом краю ближе этого уже есть точка, линия идёт в неё, а не добавляет новую")
    gap: FloatProperty(
        name="Мин. расстояние", default=1.5, min=0.0, soft_max=5.0, unit='LENGTH',
        description="Две линии ближе этого друг к другу — оставить одну, чтобы не было узких полосок")
    angle: FloatProperty(
        name="Допуск угла", default=math.radians(10.0), min=math.radians(1.0), max=math.radians(45.0),
        subtype='ANGLE',
        description="Точка края даёт линию, если край у неё отклоняется от направления площадки не больше этого")
    thin: FloatProperty(
        name="Насквозь через", default=1.5, min=0.0, soft_max=5.0, unit='LENGTH',
        description="Линия проходит насквозь через узкие полосы (бордюр) не шире этого; на широкой "
                    "грани, где уже есть разметка, останавливается")
    min_area: FloatProperty(
        name="Мин. площадь", default=30.0, min=0.0, soft_max=500.0,
        description="Резать только грани больше этой площади (м²): бордюры и места разметки не трогаются")
    show_help: BoolProperty(name="Помощь", default=False)

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH' and context.edit_object is not None

    def draw(self, context):
        draw_params(self.layout, self, "")
        draw_help(self.layout, self, "show_help", HELP)

    def execute(self, context):
        obj = context.edit_object
        bm = bmesh.from_edit_mesh(obj.data)
        try:
            self._run(bm, obj)
        except _Fail as ex:
            self.report({'ERROR'}, str(ex))
            return {'CANCELLED'}
        bmesh.update_edit_mesh(obj.data)
        self.report({'INFO'}, describe(self.summary))
        return {'FINISHED'}


PARAM_KEYS = ("lines", "snap", "gap", "angle", "thin", "min_area")


def draw_params(layout, data, prefix):
    col = layout.column()
    col.row().prop(data, prefix + "lines", expand=True)
    col.prop(data, prefix + "snap")
    col.prop(data, prefix + "gap")
    col.prop(data, prefix + "angle")
    col.prop(data, prefix + "thin")
    col.prop(data, prefix + "min_area")


def _menu(self, context):
    self.layout.operator(MESH_OT_area_lines.bl_idname, icon='MESH_GRID')


_MENUS = (
    bpy.types.VIEW3D_MT_edit_mesh_faces,
    bpy.types.VIEW3D_MT_edit_mesh_context_menu,
)


def register():
    bpy.utils.register_class(MESH_OT_area_lines)
    for m in _MENUS:
        m.append(_menu)


def unregister():
    for m in _MENUS:
        m.remove(_menu)
    bpy.utils.unregister_class(MESH_OT_area_lines)
